
main(){

    //NIXONOK

    int inday,inmonth,inyear;
    printf("***************         *******************\n");
    printf("****************NixonOK*******************\n");
    printf("***************         *******************\n\n\n\n");
    printf("Enter The Day , Month , Year One By One Below >>>\n\n");
    scanf("%2d %2d %4d" , &inday , &inmonth ,&inyear);

    printf("\n\n\nThe date You Were Interested In Was %-2d : %-2d : %-4d \n" , inday , inmonth , inyear );


    int month2day;

    if (inmonth == 1){
        month2day = 00;
    }

    else if (inmonth == 2){
        month2day = 31;
        }

    else if (inmonth == 3){
        month2day = 31 + 28;
        }


    else if (inmonth == 4){
        month2day = 31 + 28 + 31;
        }


    else if (inmonth == 5){
        month2day = 31 + 28 + 31 + 30;
        }


    else if (inmonth == 6){
            month2day = 31 + 28 + 31 + 30 + 31;
    }

    else if (inmonth == 7){
            month2day = 31 + 28 + 31 + 30 + 31 + 30;
    }

    else if (inmonth == 8){
            month2day = 31 + 28 + 31 + 30 + 31 + 30 + 31;
    }

    else if (inmonth == 9){
            month2day = 31 + 28 + 31 + 30 + 31 + 30 + 31 + 31;
    }

    else if (inmonth == 10){
            month2day = 31 + 28 + 31 + 30 + 31 + 30 + 31 + 31 + 30;
    }

    else if (inmonth == 11){
            month2day = 31 + 28 + 31 + 30 + 31 + 30 + 31 + 31 + 30 +31;
    }
    else if (inmonth == 12){
            month2day = 31 + 28 + 31 + 30 + 31 + 30 + 31 + 31 + 30 +31 + 30;
    }

    else {
            month2day = 00;
    }
    //NIXONOK

    float year2day;

    year2day = (inyear * 365 ) + (inyear/4);

    int totalday = inday + month2day + (int) year2day ;


    printf("\n\nTotal Day's passed After Starting Calender Counting = %d\n\n" , totalday);

     //NIXONOK

      char dayname1[10] = "Sunday";
      char dayname2[10] = "Monday";
      char dayname3[10] = "Thesday";
      char dayname4[10] = "Wednesday";
      char dayname5[10] = "Thursday";
      char dayname6[10] = "Friday";
      char dayname7[10] = "Saturday";


    if (totalday%7 == 2){
        printf("\n\nToday Is %s \n\n\n" ,dayname1);


    }
     else if (totalday%7 == 3){
        printf("\n\nToday Is %s \n\n\n" ,dayname2);


    }
    else if (totalday%7 == 4){
        printf("\nToday Is %s \n\n\n" ,dayname3);

    }
    else if (totalday%7 == 5){
        printf("\nToday Is %s \n\n\n" ,dayname4);


    }
    else if (totalday%7 == 6){
        printf("\nToday Is %s \n\n\n" ,dayname5);


    }
    else if (totalday%7 == 1){
        printf("\nToday Is %s \n\n\n" ,dayname6);


    }
    else {
       printf("\nToday Is %s \n\n\n" ,dayname7);

}

   int newyear , n = 1 , i ;

   for (i=0 ; i < 50 ; i++){

   newyear = inyear + n ;

   int newvalue = (newyear*365) + (int) (newyear/4) + month2day + inday;

    printf("%-2d : %-2d : %-4d Is ",inday , inmonth , newyear);

    if (newvalue%7 == 2){
        printf(" %s \n" ,dayname1);


    }
     else if (newvalue%7 == 3){
        printf(" %s \n" ,dayname2);


    }
    else if (newvalue%7 == 4){
        printf(" %s \n" ,dayname3);

    }
    else if (newvalue%7 == 5){
        printf(" %s \n" ,dayname4);


    }
    else if (newvalue%7 == 6){
        printf(" %s \n" ,dayname5);


    }
    else if (newvalue%7 == 1){
        printf(" %s \n" ,dayname6);


    }
    else {
       printf(" %s \n" ,dayname7);

}
    n++;
   }

   getch();
}

